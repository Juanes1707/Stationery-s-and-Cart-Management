
export const state = {
  cart: [],
  sales: [] //ARRAY VACIO PARA QUE LAS VENTAS SE VEAN VISUALIZADAS EN EL HISTORIAL DE VENTAS EN TIEMPO REAL

};

export function removeFromCart(id) {
  state.cart = state.cart.filter(item => item.id !== id);
}


// Agregar producto al carrito
export function addToCart(product) {

  const existingProduct = state.cart.find(item => item.id === product.id);

  if (existingProduct) {
    existingProduct.quantity += 1;
  } else {
    state.cart.push({
      ...product,
      quantity: 1
    });
  }

}

export function increaseQuantity(id) {
  const product = state.cart.find(item => item.id === id);
  if (product) {
    product.quantity += 1;
  }
}

export function decreaseQuantity(id) {
  const product = state.cart.find(item => item.id === id);
  if (product) {
    if (product.quantity === 1) {
      /* Si la cantidad es 1, eliminar el producto del carrito */
      removeFromCart(id);
    } else {
      /* Si la cantidad es mayor a 1, solo disminuir */
      product.quantity -= 1;
    }
  }
}
//FUNCION PARA REGISTRAR UNA VENTA EN TIEMPO REAL

export function registerSale() {
  if (state.cart.length === 0) return;

  const newSale = {
    id: Date.now(),
    date: new Date().toLocaleString(),
    items: [...state.cart],
    total: state.cart.reduce((acc, item) => acc + item.price * item.quantity, 0)
  };
  
  state.sales.push(newSale);
  //VACIAR EL CARRITO
  state.cart = [];
};
