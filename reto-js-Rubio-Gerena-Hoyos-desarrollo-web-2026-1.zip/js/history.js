
export function renderHistory() {

    const historySection = document.querySelector("#historySection");

    historySection.innerHTML = `
        <h2 class="history-content-title">Historial de ventas</h2>

    `;
}